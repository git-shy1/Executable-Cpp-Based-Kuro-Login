#pragma once

#include <stdlib.h>
#include <string.h>

namespace ZUtils {
    
    char * b_hex(char * arr, int size);
    
    int hex_b(char *hex, char * out);
    
}